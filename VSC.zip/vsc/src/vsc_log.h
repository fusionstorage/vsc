/*
 *    Linux scsi driver module for Fusion Storage.
 *    Copyright (C) Huawei Technologies, 2012.
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; version 2 of the License.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *    General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 300, Boston, MA
 *    02111-1307, USA.
 *    
 *    Author: Peng Ruilin
 */
 

#ifndef __VSC_LOG_H_
#define __VSC_LOG_H_

typedef enum 
{
    VSC_ERR     = 0,
    VSC_INFO    = 1,
    VSC_DBG     = 2,
    VSC_TYPE_COUNT,
}enum_vsc_log_type;

#define VSC_TRACE_IOCTL_EVENT         (1 << 0)
#define VSC_TRACE_REQ_SCSI_CMD        (1 << 1)
#define VSC_TRACE_RSP_SCSI_CMD        (1 << 2)
#define VSC_TRACE_REQ_EVENT           (1 << 3)
#define VSC_TRACE_RSP_EVENT           (1 << 4)

#define PREFIX "%s():%d "

#define vsc_err(fmt, arg...)  \
    do { printk(KERN_ERR PREFIX fmt , __FUNCTION__, __LINE__, ## arg); \
    } while (0)
#define vsc_err_limit(fmt, arg...) \
    do { if (printk_ratelimit()) printk(KERN_ERR PREFIX fmt , __FUNCTION__, __LINE__, ## arg); \
    } while (0)
#define vsc_info(fmt, arg...)  \
    do { printk(KERN_NOTICE PREFIX fmt , __FUNCTION__, __LINE__, ## arg); \
    } while (0)

#define vsc_dbg(fmt, arg...)  \
    do { if ( log_level >= VSC_DBG) \
        printk(KERN_DEBUG PREFIX fmt , __FUNCTION__, __LINE__, ## arg); \
    } while (0)

extern enum_vsc_log_type log_level;
extern unsigned long     trace_switch;

#endif

