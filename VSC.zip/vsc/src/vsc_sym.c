/*
 *    Linux scsi driver module for Fusion Storage.
 *    Copyright (C) Huawei Technologies, 2012.
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; version 2 of the License.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *    General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 300, Boston, MA
 *    02111-1307, USA.
 *    
 *    Author: Peng Ruilin
 */
 
#include "vsc_common.h"
#include "vsc_sym.h"

/**************************************************************************
 ��������  : ���ݽṹ�Ƿ������
          
 ��    ��  : 
 �� �� ֵ  : ��ʼ�����
**************************************************************************/
static int vsc_sym_data_align_chk(void) 
{
    if (sizeof(struct vsc_scsi_data_msg) != offsetof(struct vsc_scsi_data_msg, data)) {
        vsc_err("struct vsc_scsi_data_msg is not align.");
        return -EFAULT;
    }

    if (sizeof(struct vsc_scsi_data) != offsetof(struct vsc_scsi_data, vec)) {
        vsc_err("struct vsc_scsi_data is not align.");
        return -EFAULT;
    }

    if (sizeof(struct vsc_scsi_event) != offsetof(struct vsc_scsi_event, data)) {
        vsc_err("struct vsc_scsi_event is not align.");
        return -EFAULT;
    }

    if (sizeof(struct vsc_scsi_msg_data) != offsetof(struct vsc_scsi_msg_data, data)) {
        vsc_err("struct vsc_scsi_msg_data is not align.");
        return -EFAULT;
    }

    return 0;
}

/**************************************************************************
 ��������  : �������ų�ʼ��
          
 ��    ��  : 
 �� �� ֵ  : ��ʼ�����
**************************************************************************/
int __init vsc_sym_init(void)
{
    int retval = 0;

    /* �����Ϣ�ṹ�е�data�Ƿ���� */
    retval = vsc_sym_data_align_chk();
    if (retval ) {
        vsc_err("struct align check failed.\n");
    }
    return retval;
}

/**************************************************************************
 ��������  : sym�˳�����,sym���Ա�����ֵ�����跴��ʼ����
          
 ��    ��  : 
 �� �� ֵ  : 
**************************************************************************/
int vsc_sym_exit(void)
{
    return 0;
}

